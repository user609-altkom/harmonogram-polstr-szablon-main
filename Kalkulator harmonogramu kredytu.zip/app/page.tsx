'use client';

import { FormEvent, useRef, useState } from 'react';

type Wskaznik = 'POLSTR_1M' | 'WIBOR_3M';
type TypRat = 'rowne' | 'malejace';
type TrybNadplaty = 'obniz_rate' | 'skroc_okres';

type Nadplata = { id: number; miesiac: string; kwota: string; tryb: TrybNadplaty };

type Rata = {
  nr: number;
  data: string;
  kapital: number;
  odsetki: number;
  rata: number;
  saldo: number;
};

type Status = 'idle' | 'loading' | 'error' | 'success';

const parseNum = (v: string) => parseFloat(v.replace(/[\s\u00a0]/g, '').replace(',', '.'));

const formatPLN = (v: number) => {
  const [i, d] = Math.abs(v).toFixed(2).split('.');
  return (v < -0.004 ? '−' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0') + ',' + d;
};

const formatDate = (v: string) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : v;
};

const normalize = (raw: unknown): Rata[] => {
  const obj = raw as { raty?: unknown; harmonogram?: unknown };
  const list = Array.isArray(raw) ? raw : Array.isArray(obj?.raty) ? obj.raty : Array.isArray(obj?.harmonogram) ? obj.harmonogram : [];
  return (list as Record<string, unknown>[]).map((r, idx) => ({
    nr: Number(r.nr ?? idx + 1),
    data: String(r.data ?? ''),
    kapital: Number(r.kapital ?? 0),
    odsetki: Number(r.odsetki ?? 0),
    rata: Number(r.rata ?? 0),
    saldo: Number(r.saldo ?? 0),
  }));
};

const inputCls =
  'w-full min-h-11 rounded-[2px] border border-[#201e1d]/15 bg-[#eae9e9] px-3 text-[15px] text-[#201e1d] caret-[#0088b0] placeholder:text-[#201e1d]/60 hover:border-[#201e1d]/45 focus:border-[#0088b0] focus:outline-none focus-visible:outline-2 focus-visible:outline-[#0088b0]';
const labelCls = 'mb-1.5 block text-xs text-[#201e1d]/75';
const kickerCls = 'text-[11px] font-semibold uppercase tracking-[0.08em] text-[#605d5d]';

function Segmented<T extends string>({
  name,
  value,
  options,
  onChange,
}: {
  name: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div role="radiogroup" className="flex overflow-hidden rounded-[2px] border border-[#201e1d]/15">
      {options.map((o, i) => (
        <label
          key={o.value}
          className={`flex min-h-11 flex-1 cursor-pointer items-center justify-center px-3 text-sm has-[:focus-visible]:outline-2 has-[:focus-visible]:-outline-offset-2 has-[:focus-visible]:outline-[#0088b0] ${
            i > 0 ? 'border-l border-[#201e1d]/15' : ''
          } ${value === o.value ? 'bg-[#0088b0] text-[#f3f2f2]' : 'hover:bg-[#201e1d]/[0.07]'}`}
        >
          <input
            type="radio"
            name={name}
            value={o.value}
            checked={value === o.value}
            onChange={() => onChange(o.value)}
            className="sr-only"
          />
          {o.label}
        </label>
      ))}
    </div>
  );
}

export default function Page() {
  const [kwota, setKwota] = useState('');
  const [liczbaRat, setLiczbaRat] = useState('');
  const [dataPierwszejRaty, setDataPierwszejRaty] = useState('');
  const [marza, setMarza] = useState('');
  const [wskaznik, setWskaznik] = useState<Wskaznik>('WIBOR_3M');
  const [typRat, setTypRat] = useState<TypRat>('rowne');
  const [nadplaty, setNadplaty] = useState<Nadplata[]>([]);
  const nextId = useRef(1);

  const [status, setStatus] = useState<Status>('idle');
  const [raty, setRaty] = useState<Rata[]>([]);
  const [formError, setFormError] = useState('');
  const [apiError, setApiError] = useState('');
  const abortRef = useRef<AbortController | null>(null);

  const addNadplata = () =>
    setNadplaty((l) => [...l, { id: nextId.current++, miesiac: '', kwota: '', tryb: 'obniz_rate' }]);
  const updateNadplata = (id: number, patch: Partial<Nadplata>) =>
    setNadplaty((l) => l.map((n) => (n.id === id ? { ...n, ...patch } : n)));
  const removeNadplata = (id: number) => setNadplaty((l) => l.filter((n) => n.id !== id));

  const validate = (): string => {
    const n = parseInt(liczbaRat, 10);
    if (!(parseNum(kwota) > 0)) return 'Podaj kwotę kredytu.';
    if (!(n > 0 && n <= 480)) return 'Liczba rat musi mieścić się w zakresie 1–480.';
    if (!dataPierwszejRaty) return 'Podaj datę pierwszej raty.';
    if (!(parseNum(marza) >= 0)) return 'Podaj marżę w punktach procentowych.';
    for (const o of nadplaty) {
      const m = parseInt(o.miesiac, 10);
      if (!(m >= 1 && m <= n) || !(parseNum(o.kwota) > 0))
        return 'Uzupełnij poprawnie nr raty i kwotę każdej nadpłaty.';
    }
    return '';
  };

  const onSubmit = async (e?: FormEvent) => {
    e?.preventDefault();
    const err = validate();
    setFormError(err);
    if (err) return;

    const params = new URLSearchParams({
      kwota: String(parseNum(kwota)),
      liczbaRat: String(parseInt(liczbaRat, 10)),
      dataPierwszejRaty,
      marza: String(parseNum(marza)),
      wskaznik,
      typRat,
    });
    if (nadplaty.length) {
      params.set(
        'nadplaty',
        JSON.stringify(
          nadplaty.map((n) => ({ miesiac: parseInt(n.miesiac, 10), kwota: parseNum(n.kwota), tryb: n.tryb })),
        ),
      );
    }

    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setStatus('loading');
    setApiError('');

    try {
      const res = await fetch(`/api/harmonogram?${params.toString()}`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        cache: 'no-store',
        signal: ctrl.signal,
      });
      if (!res.ok) throw new Error(`Błąd serwera (${res.status}).`);
      const list = normalize(await res.json());
      if (!list.length) throw new Error('Odpowiedź nie zawiera harmonogramu.');
      setRaty(list);
      setStatus('success');
    } catch (error) {
      if ((error as Error).name === 'AbortError') return;
      setApiError((error as Error).message || 'Nieznany błąd.');
      setStatus('error');
    }
  };

  const exportCsv = () => {
    if (!raty.length) return;
    const f = (v: number) => v.toFixed(2).replace('.', ',');
    const lines = [
      'Nr;Data;Kapitał;Odsetki;Rata;Saldo',
      ...raty.map((r) => [r.nr, formatDate(r.data), f(r.kapital), f(r.odsetki), f(r.rata), f(r.saldo)].join(';')),
    ];
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `harmonogram-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const hasResults = status === 'success' && raty.length > 0;
  const rataPierwsza = hasResults ? raty[0].rata : 0;
  const rataOstatnia = hasResults ? raty[raty.length - 1].rata : 0;
  const sumaOdsetek = raty.reduce((s, r) => s + r.odsetki, 0);
  const planned = parseInt(liczbaRat, 10);

  return (
    <main
      className="min-h-screen bg-[#f3f2f2] text-[#201e1d] [font-variant-numeric:tabular-nums]"
      style={{ fontFamily: '"Source Serif 4", Georgia, "Times New Roman", serif' }}
    >
      <div className="mx-auto max-w-[1320px] px-4 pb-16 pt-6 sm:px-8 sm:pt-10 lg:px-12 lg:pt-12">
        <header className="mb-10">
          <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#006786]">Kredyt hipoteczny</p>
          <h1 className="mt-2 text-[30px] font-semibold leading-tight tracking-[-0.015em] sm:text-[44px]">
            Kalkulator harmonogramu kredytu
          </h1>
          <div className="mt-4 flex flex-col gap-[2px]" aria-hidden="true">
            <div className="h-[3px] bg-[#201e1d]" />
            <div className="h-px bg-[#201e1d]" />
          </div>
        </header>

        <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-[340px_minmax(0,1fr)] lg:gap-16">
          {/* Formularz */}
          <form onSubmit={onSubmit} noValidate className="flex flex-col gap-8">
            <section className="flex flex-col gap-5">
              <h2 className={kickerCls}>Parametry kredytu</h2>

              <div>
                <label htmlFor="kwota" className={labelCls}>Kwota kredytu (PLN)</label>
                <input
                  id="kwota"
                  type="text"
                  inputMode="decimal"
                  autoComplete="off"
                  placeholder="np. 650 000"
                  value={kwota}
                  onChange={(e) => setKwota(e.target.value)}
                  className={`${inputCls} text-lg`}
                />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-2">
                <div>
                  <label htmlFor="liczbaRat" className={labelCls}>Liczba rat</label>
                  <input
                    id="liczbaRat"
                    type="number"
                    min={1}
                    max={480}
                    placeholder="np. 360"
                    value={liczbaRat}
                    onChange={(e) => setLiczbaRat(e.target.value)}
                    className={inputCls}
                  />
                </div>
                <div>
                  <label htmlFor="dataPierwszejRaty" className={labelCls}>Data pierwszej raty</label>
                  <input
                    id="dataPierwszejRaty"
                    type="date"
                    value={dataPierwszejRaty}
                    onChange={(e) => setDataPierwszejRaty(e.target.value)}
                    className={inputCls}
                  />
                </div>
              </div>

              <div>
                <label htmlFor="marza" className={labelCls}>Marża (p.p.)</label>
                <input
                  id="marza"
                  type="text"
                  inputMode="decimal"
                  placeholder="np. 1,85"
                  value={marza}
                  onChange={(e) => setMarza(e.target.value)}
                  className={inputCls}
                />
              </div>

              <div>
                <span className={labelCls}>Wskaźnik referencyjny</span>
                <Segmented
                  name="wskaznik"
                  value={wskaznik}
                  onChange={setWskaznik}
                  options={[
                    { value: 'POLSTR_1M', label: 'POLSTR 1M' },
                    { value: 'WIBOR_3M', label: 'WIBOR 3M' },
                  ]}
                />
              </div>

              <div>
                <span className={labelCls}>Typ rat</span>
                <Segmented
                  name="typRat"
                  value={typRat}
                  onChange={setTypRat}
                  options={[
                    { value: 'rowne', label: 'Równe' },
                    { value: 'malejace', label: 'Malejące' },
                  ]}
                />
              </div>
            </section>

            <section className="flex flex-col gap-3">
              <div className="flex items-baseline justify-between gap-2">
                <h2 className={kickerCls}>Nadpłaty</h2>
                <button
                  type="button"
                  onClick={addNadplata}
                  className="inline-flex min-h-9 items-center gap-1.5 rounded-[2px] px-1.5 text-sm font-semibold text-[#0088b0] hover:bg-[#0088b0]/10 active:bg-[#0088b0]/20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0088b0]"
                >
                  <svg width="14" height="14" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true">
                    <path d="M224 128a8 8 0 0 1-8 8h-80v80a8 8 0 0 1-16 0v-80H40a8 8 0 0 1 0-16h80V40a8 8 0 0 1 16 0v80h80a8 8 0 0 1 8 8Z" />
                  </svg>
                  Dodaj nadpłatę
                </button>
              </div>

              {nadplaty.length === 0 && <p className="text-[13px] text-[#605d5d]">Brak nadpłat w harmonogramie.</p>}

              {nadplaty.map((n) => (
                <div key={n.id} className="grid grid-cols-[84px_minmax(0,1fr)] gap-2 pb-3">
                  <div>
                    <label htmlFor={`np-m-${n.id}`} className={labelCls}>Nr raty</label>
                    <input
                      id={`np-m-${n.id}`}
                      type="number"
                      min={1}
                      value={n.miesiac}
                      onChange={(e) => updateNadplata(n.id, { miesiac: e.target.value })}
                      className={inputCls}
                    />
                  </div>
                  <div>
                    <label htmlFor={`np-k-${n.id}`} className={labelCls}>Kwota (PLN)</label>
                    <input
                      id={`np-k-${n.id}`}
                      type="text"
                      inputMode="decimal"
                      value={n.kwota}
                      onChange={(e) => updateNadplata(n.id, { kwota: e.target.value })}
                      className={inputCls}
                    />
                  </div>
                  <div className="col-span-2 flex items-end gap-2">
                    <div className="min-w-0 flex-1">
                      <label htmlFor={`np-t-${n.id}`} className={labelCls}>Tryb</label>
                      <select
                        id={`np-t-${n.id}`}
                        value={n.tryb}
                        onChange={(e) => updateNadplata(n.id, { tryb: e.target.value as TrybNadplaty })}
                        className={inputCls}
                      >
                        <option value="obniz_rate">Obniż ratę</option>
                        <option value="skroc_okres">Skróć okres</option>
                      </select>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeNadplata(n.id)}
                      aria-label={`Usuń nadpłatę ${n.miesiac ? `po racie ${n.miesiac}` : ''}`}
                      className="min-h-11 rounded-[2px] border border-[#201e1d]/15 px-4 text-sm font-semibold hover:bg-[#201e1d]/[0.07] active:bg-[#201e1d]/[0.14] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0088b0]"
                    >
                      Usuń
                    </button>
                  </div>
                </div>
              ))}
            </section>

            <div className="flex flex-col gap-2">
              {formError && (
                <p role="alert" className="text-[13px] text-[#aa0b56]">{formError}</p>
              )}
              <button
                type="submit"
                disabled={status === 'loading'}
                className="min-h-12 w-full rounded-[2px] bg-[#0088b0] text-base font-semibold text-[#f3f2f2] hover:bg-[#1186ac] active:bg-[#006786] disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0088b0]"
              >
                {status === 'loading' ? 'Liczenie…' : 'Policz'}
              </button>
            </div>
          </form>

          {/* Wyniki */}
          <section aria-live="polite" className="flex min-w-0 flex-col gap-8">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <div className="flex flex-col gap-1">
                <h2 className={kickerCls}>Wynik</h2>
                {hasResults && (
                  <span className="text-sm text-[#605d5d]">
                    {raty.length < planned ? `${raty.length} rat (skrócono z ${planned} po nadpłatach)` : `${raty.length} rat`}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={exportCsv}
                disabled={!hasResults}
                className="inline-flex min-h-10 items-center gap-1.5 rounded-[2px] border border-[#201e1d]/15 px-4 text-sm font-semibold hover:bg-[#201e1d]/[0.07] active:bg-[#201e1d]/[0.14] disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0088b0]"
              >
                <svg width="16" height="16" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true">
                  <path d="M208 144v64H48v-64Z" opacity=".2" />
                  <path d="M224 144v64a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16v-64a8 8 0 0 1 16 0v64h160v-64a8 8 0 0 1 16 0Zm-101.66 5.66a8 8 0 0 0 11.32 0l40-40a8 8 0 0 0-11.32-11.32L136 124.69V32a8 8 0 0 0-16 0v92.69L93.66 98.34a8 8 0 0 0-11.32 11.32Z" />
                </svg>
                Eksport CSV
              </button>
            </div>

            {status === 'idle' && (
              <p className="max-w-[44ch] text-lg leading-relaxed text-[#605d5d]">
                Uzupełnij parametry kredytu i kliknij „Policz”, aby wyświetlić harmonogram spłat.
              </p>
            )}

            {status === 'loading' && <p className="text-lg text-[#605d5d]">Pobieranie harmonogramu…</p>}

            {status === 'error' && (
              <div role="alert" className="flex flex-col items-start gap-3">
                <p className="max-w-[52ch] text-lg leading-relaxed text-[#aa0b56]">
                  Nie udało się pobrać harmonogramu. {apiError} Sprawdź parametry i spróbuj ponownie.
                </p>
                <button
                  type="button"
                  onClick={() => onSubmit()}
                  className="min-h-10 rounded-[2px] border border-[#201e1d]/15 px-4 text-sm font-semibold hover:bg-[#201e1d]/[0.07] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0088b0]"
                >
                  Spróbuj ponownie
                </button>
              </div>
            )}

            {hasResults && (
              <>
                <dl className="grid grid-cols-1 gap-6 sm:grid-cols-3">
                  {[
                    { label: 'Rata pierwsza', value: rataPierwsza, accent: false },
                    { label: 'Rata ostatnia', value: rataOstatnia, accent: false },
                    { label: 'Suma odsetek', value: sumaOdsetek, accent: true },
                  ].map((s) => (
                    <div key={s.label} className="flex flex-col gap-1">
                      <dt className="text-[13px] text-[#605d5d]">{s.label}</dt>
                      <dd
                        className={`text-[28px] font-semibold leading-tight tracking-[-0.01em] lg:text-[34px] ${
                          s.accent ? 'text-[#006786]' : ''
                        }`}
                      >
                        {formatPLN(s.value)} <span className="text-[15px] font-normal text-[#605d5d]">PLN</span>
                      </dd>
                    </div>
                  ))}
                </dl>

                <div className="max-h-[620px] overflow-auto border-t border-[#201e1d]">
                  <table className="w-full min-w-[680px] border-collapse text-sm">
                    <caption className="sr-only">Harmonogram rat</caption>
                    <thead className="sticky top-0 z-10 bg-[#f3f2f2]">
                      <tr className="border-b border-[#201e1d]/15 text-[11px] uppercase tracking-[0.08em] text-[#605d5d]">
                        <th scope="col" className="w-14 px-2.5 py-3 text-left font-semibold">Nr</th>
                        <th scope="col" className="w-28 px-2.5 py-3 text-left font-semibold">Data</th>
                        <th scope="col" className="px-2.5 py-3 text-right font-semibold">Kapitał</th>
                        <th scope="col" className="px-2.5 py-3 text-right font-semibold">Odsetki</th>
                        <th scope="col" className="px-2.5 py-3 text-right font-semibold text-[#201e1d]">Rata</th>
                        <th scope="col" className="px-2.5 py-3 text-right font-semibold">Saldo</th>
                      </tr>
                    </thead>
                    <tbody>
                      {raty.map((r) => (
                        <tr key={r.nr} className="border-b border-[#201e1d]/[0.08] hover:bg-[#201e1d]/[0.04]">
                          <td className="px-2.5 py-2.5 text-[#605d5d]">{r.nr}</td>
                          <td className="px-2.5 py-2.5">{formatDate(r.data)}</td>
                          <td className="px-2.5 py-2.5 text-right">{formatPLN(r.kapital)}</td>
                          <td className="px-2.5 py-2.5 text-right">{formatPLN(r.odsetki)}</td>
                          <td className="px-2.5 py-2.5 text-right font-semibold">{formatPLN(r.rata)}</td>
                          <td className="px-2.5 py-2.5 text-right">{formatPLN(r.saldo)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-[#605d5d]">Kwoty w PLN.</p>
              </>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
